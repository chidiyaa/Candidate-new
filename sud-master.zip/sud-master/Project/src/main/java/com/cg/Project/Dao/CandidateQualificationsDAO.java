package com.cg.Project.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Project.Bean.CandidateQualifications;



public interface CandidateQualificationsDAO extends JpaRepository <CandidateQualifications,String> {


}